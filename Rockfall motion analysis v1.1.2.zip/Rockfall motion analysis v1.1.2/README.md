# Rockfall motion analysis
Cite as: 
Liping GUO. (2022). Rockfall impact signal extraction (latest version). Zenodo. 

https://doi.org/10.5281/zenodo.6482603