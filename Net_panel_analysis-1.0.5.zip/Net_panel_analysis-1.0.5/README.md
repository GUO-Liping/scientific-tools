# Net Panel Analysis
To analysis different types of net panels in flexible barriers.
type1: Steel Wire Ring Net
